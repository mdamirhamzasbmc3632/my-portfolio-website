import { profileData, personalDetailsData, workExperienceData, academicList } from '../data';

export function downloadCV(): void {
  const content = `=====================================================
CURRICULUM VITAE
Md Amir Hamza (মোঃ আমির হামজা)
Digital Marketing Specialist & Creative Media Strategist
Contact No: ${profileData.whatsapp}
E-mail: ${profileData.email}
Address: ${profileData.location}
=====================================================

CAREER OBJECTIVE:
${profileData.careerObjective || 'To obtain a position with opportunities to utilize my technical, branding and marketing experiences, skill, talent, creativity, sincerity for the better achievement of the organization.'}

PERSONAL INFORMATION:
Father's Name    : ${personalDetailsData.fatherName}
Mother's Name    : ${personalDetailsData.motherName}
Date of Birth    : ${personalDetailsData.dob}
Marital Status   : ${personalDetailsData.maritalStatus}
Religion         : ${personalDetailsData.religion}
Permanent Address: ${personalDetailsData.permanentAddress}

WORK EXPERIENCES:
❖ ${workExperienceData[0].role}
  Organization: ${workExperienceData[0].organization} (Website: https://iqraonlinemadrasa.com/)
  • Marketing Assistant (Key Role): Assisted in digital marketing campaigns, promotional outreach, student enrollment drives, and social media coordination.
  • Provided end-to-end technical support to teachers and students, ensuring seamless navigation of LMS, educational software, and hardware tools.
  • Streamlined daily operational workflows to enhance administrative efficiency and improve academic delivery.
  • Integrated digital communication pipelines, Google Workspace tools, and managed online educational systems.

SPECIAL EXPERIENCE & EXPERTISE:
• 1. Digital Marketing & Meta Ads Specialist (Facebook & Instagram Ads Strategy, Campaign Setup & ROAS)
• 2. High-Retention Video Editing (Commercial Promo Ads, Social Reels & Pacing)
• 3. Graphic Design & Ad Creatives (Photoshop, Illustrator, High CTR Thumbnails & Branding)

LANGUAGE PROFICIENCY:
• Fluent speaking & writing ability in Bengali.
• Basic speaking & writing ability in English.

EDUCATIONAL QUALIFICATION:
1. TAKMEEL FIL HADITH
   Institute    : Jamia Arabia Imdadul Uloom Faridabad
   Subject      : Al-Hadith And Islamic Studies
   Passing Year : 2026
   Result       : GPA 4 (Out of 5.00)

2. SHORHE BEKAYA
   Institute    : JAMIA ISLAMIA MIFTAHUL ULUM BADDA
   Group        : General
   Passing Year : 2023
   Result       : GPA 5 (Out of 5.00)

3. HIFJUL QURAN
   Institute    : ROTARGOWN HOSSAINIA HAFIJIA MADRASA
   Passing Year : 2017
   Result       : GPA 5 (Out of 5.00)

PROFESSIONAL TRAINING:
• As-Sunnah Skill Development Institute - SBMC (Small Business Management Course) - Batch 36
  Modules: Meta Marketing, Video Editing, Graphic Design, Generative AI & Google Workspace.

CONTACT & CONNECT:
Phone/WhatsApp: ${profileData.whatsapp}
Email: ${profileData.email}
Location: ${profileData.location}
=====================================================`;

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Md_Amir_Hamza_CV.txt';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
