import React from 'react';
import { Pencil, Sliders } from 'lucide-react';
import { useSiteConfig } from '../context/SiteConfigContext';

interface SectionEditButtonProps {
  sectionKey: 'hero' | 'portfolio' | 'expertise' | 'education' | 'contact' | 'theme';
  labelBn?: string;
  labelEn?: string;
  className?: string;
}

export const SectionEditButton: React.FC<SectionEditButtonProps> = ({
  sectionKey,
  labelBn = 'এই সেকশনটি এডিট করুন',
  labelEn = 'Edit Section',
  className = '',
}) => {
  const { isEditMode, setActiveEditSection } = useSiteConfig();

  // If edit mode is not active, display nothing or a very discreet trigger on hover
  if (!isEditMode) {
    return (
      <button
        type="button"
        onClick={() => setActiveEditSection(sectionKey)}
        className={`absolute top-4 right-4 z-20 opacity-0 hover:opacity-100 focus:opacity-100 transition-opacity inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0d0e14]/90 hover:bg-[#161822] border border-sky-500/40 text-sky-400 text-xs font-semibold backdrop-blur-md shadow-lg cursor-pointer ${className}`}
        title={`${labelEn} / ${labelBn}`}
      >
        <Pencil className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">{labelBn}</span>
      </button>
    );
  }

  return (
    <div className={`absolute top-4 right-4 z-20 flex items-center gap-2 ${className}`}>
      <button
        type="button"
        onClick={() => setActiveEditSection(sectionKey)}
        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 text-slate-950 text-xs font-bold shadow-[0_0_15px_rgba(56,189,248,0.5)] transition-all cursor-pointer transform hover:scale-105"
        title={`${labelEn} / ${labelBn}`}
      >
        <Pencil className="w-3.5 h-3.5 shrink-0" />
        <span>{labelBn}</span>
      </button>
    </div>
  );
};
